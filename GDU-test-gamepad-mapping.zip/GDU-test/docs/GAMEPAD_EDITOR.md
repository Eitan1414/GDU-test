# GDU GamePad editor specification

The editor is designed around the Wii U GamePad's 854×480 screen. Object choice and placement are deliberately touch-first, like a console creation tool, while physical buttons provide fast shortcuts.

## Screen layout

- **Top bar:** level navigation, undo/redo, zoom and test.
- **Center:** visible portion of the level. Off-screen objects are not drawn.
- **Bottom dock:** touch categories and paged object palette.
- **Pause overlay:** quick resume, save, settings and return to the level browser.
- **Tutorial overlay:** complete GamePad mapping, available at any time with Select/Minus.

## Final GamePad mapping

### Gameplay

| Control | Action |
|---|---|
| **A** | Jump; activate jump orbs and contextual transformations |
| **Touch** | Jump in the browser prototype |
| **Start / Plus** | Open or close the pause menu |
| **Select / Minus** | Open or close the tutorial |

### Editor

| Control | Action |
|---|---|
| **Stylus / GamePad touch** | Choose an item in the palette and place, select, move or erase it on the map |
| **A** | Launch an immediate level test |
| **B** | Undo the last modification |
| **D-pad Right** | Go to the next item page |
| **D-pad Left** | Go to the previous item page |
| **R** | Go to the next item category |
| **L** | Go to the previous item category |
| **Start / Plus** | Open or close the pause menu |
| **Select / Minus** | Open or close the editor tutorial |

A and B never place or erase objects in editor mode. Editing remains touch/stylus-only so accidental button presses cannot alter the level.

## Touch interaction

- Touch an object in the bottom dock to select it.
- Touch or drag on the map to place it continuously.
- Use **Selection** to pick and move an object.
- Use **Gomme** to erase continuously.
- Use **Déplacer** or two fingers to pan through a long level.
- Use the timeline strip for fast horizontal navigation.

## Performance choices

- Fixed 120 Hz gameplay simulation with an eight-step safety cap.
- Jump buffering and coyote time for responsive controls.
- Spatial indexing for nearby collision checks only.
- Viewport-sized editor canvas; off-screen objects are skipped.
- Device pixel ratio capped at 1.5.
- One undo snapshot per touch gesture rather than one per tile.
- Two objects per palette page for large, reliable GamePad touch targets.

## Native Wii U status

The complete mapping, menus, tutorial and touch workflow are implemented in the browser prototype. The current RPX contains the gameplay mapping and pause behavior through wut's development console. Native GX2/SDL2 rendering and direct VPAD touch-coordinate wiring remain the next renderer milestone.
