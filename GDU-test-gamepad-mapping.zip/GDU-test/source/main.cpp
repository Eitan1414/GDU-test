#include <coreinit/thread.h>
#include <coreinit/time.h>
#include <vpad/input.h>
#include <whb/log.h>
#include <whb/log_console.h>
#include <whb/proc.h>

#include <algorithm>
#include <cstdint>

#include "gdu/Game.hpp"

namespace {
enum class Screen {
    LevelSelect,
    Playing,
    Paused,
};

const char* stateName(gdu::RunState state) {
    switch (state) {
        case gdu::RunState::Playing:
            return "PLAY";
        case gdu::RunState::Dead:
            return "DEAD - A to retry";
        case gdu::RunState::Complete:
            return "COMPLETE - A to retry";
    }
    return "UNKNOWN";
}

void printLevelCard(const gdu::Game& game) {
    const auto& level = game.level();
    WHBLogPrintf("----------------------------------------");
    WHBLogPrintf("LEVEL %02u / %02u", static_cast<unsigned>(game.levelIndex() + 1U),
                 static_cast<unsigned>(gdu::kLevelCount));
    WHBLogPrintf("%s", level.name);
    WHBLogPrintf("Difficulty %u/10 | Stars %u | %u BPM",
                 static_cast<unsigned>(level.difficulty),
                 static_cast<unsigned>(level.stars),
                 static_cast<unsigned>(level.bpm));
    WHBLogPrintf("Track: %s", level.music);
    WHBLogPrintf("L/R or Left/Right browse | A play | X editor status");
}

void printPauseMenu() {
    WHBLogPrintf("----------------------------------------");
    WHBLogPrintf("PAUSE");
    WHBLogPrintf("PLUS/A: resume | B: level browser");
    WHBLogPrintf("MINUS: editor controls tutorial");
}

void printEditorTutorial() {
    WHBLogPrintf("----------------------------------------");
    WHBLogPrintf("EDITOR GAMEPAD MAPPING");
    WHBLogPrintf("Touch/stylus: choose and place items");
    WHBLogPrintf("A: test | B: undo");
    WHBLogPrintf("D-pad Left/Right: previous/next item page");
    WHBLogPrintf("L/R: previous/next item category");
    WHBLogPrintf("PLUS: pause | MINUS: tutorial");
}
}  // namespace

int main(int, char**) {
    WHBProcInit();
    WHBLogConsoleInit();
    WHBLogPrintf("GDU: Pulse Rift - Wii U alpha");
    WHBLogPrintf("A jumps/interacts | PLUS pause | MINUS tutorial");

    gdu::Game game;
    Screen screen = Screen::LevelSelect;
    Screen screenBeforePause = Screen::Playing;
    std::uint32_t frame = 0;
    printLevelCard(game);

    while (WHBProcIsRunning()) {
        VPADStatus status{};
        VPADReadError error{};
        VPADRead(VPAD_CHAN_0, &status, 1, &error);

        const std::uint32_t trigger = status.trigger;

        if ((trigger & VPAD_BUTTON_MINUS) != 0U) {
            printEditorTutorial();
        }

        if (screen == Screen::Paused) {
            if ((trigger & (VPAD_BUTTON_PLUS | VPAD_BUTTON_A)) != 0U) {
                screen = screenBeforePause;
                WHBLogPrintf("RESUME");
            } else if ((trigger & VPAD_BUTTON_B) != 0U) {
                screen = Screen::LevelSelect;
                printLevelCard(game);
            }
            WHBLogConsoleDraw();
            OSSleepTicks(OSMillisecondsToTicks(16));
            continue;
        }

        if (screen == Screen::LevelSelect) {
            int direction = 0;
            if ((trigger & (VPAD_BUTTON_L | VPAD_BUTTON_LEFT)) != 0U) {
                direction = -1;
            } else if ((trigger & (VPAD_BUTTON_R | VPAD_BUTTON_RIGHT)) != 0U) {
                direction = 1;
            }

            if (direction != 0) {
                const int count = static_cast<int>(gdu::kLevelCount);
                const int current = static_cast<int>(game.levelIndex());
                const auto next = static_cast<std::size_t>((current + direction + count) % count);
                game.selectLevel(next);
                printLevelCard(game);
            }

            if ((trigger & VPAD_BUTTON_A) != 0U) {
                game.restart();
                screen = Screen::Playing;
                WHBLogPrintf("PLAYING %s", game.level().name);
            }

            if ((trigger & VPAD_BUTTON_X) != 0U) {
                printEditorTutorial();
                WHBLogPrintf("Native touch editor rendering is the next GX2/SDL milestone.");
            }
        } else if (screen == Screen::Playing) {
            if ((trigger & VPAD_BUTTON_PLUS) != 0U) {
                screenBeforePause = Screen::Playing;
                screen = Screen::Paused;
                printPauseMenu();
            } else {
                gdu::InputFrame input{};
                input.jumpPressed = (trigger & VPAD_BUTTON_A) != 0U;
                input.restartPressed = false;
                game.update(1.0F / 60.0F, input);

                if ((frame++ % 15U) == 0U) {
                    const int percent = static_cast<int>(game.progress() * 100.0F);
                    WHBLogPrintf("L%02u %-18s | %3d%% | y=%4.1f | try %u | %s",
                                 static_cast<unsigned>(game.levelIndex() + 1U),
                                 game.level().name,
                                 std::clamp(percent, 0, 100),
                                 game.playerY(),
                                 game.attempts(),
                                 stateName(game.state()));
                }
            }
        }

        WHBLogConsoleDraw();
        OSSleepTicks(OSMillisecondsToTicks(16));
    }

    WHBLogPrintf("Exiting GDU...");
    WHBLogConsoleDraw();
    OSSleepTicks(OSMillisecondsToTicks(250));
    WHBLogConsoleFree();
    WHBProcShutdown();
    return 0;
}
