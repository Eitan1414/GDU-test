#include "gdu/Game.hpp"

#include <algorithm>
#include <cmath>

namespace gdu {
namespace {
constexpr float kBaseHorizontalUnitsPerSecond = 8.2F;
constexpr float kGravity = 31.0F;
constexpr float kJumpVelocity = 11.7F;
constexpr float kPadVelocity = 15.2F;
constexpr float kCollisionHeight = 0.72F;
constexpr float kJumpBufferSeconds = 0.12F;
constexpr float kCoyoteSeconds = 0.08F;
constexpr float kMaximumStep = 1.0F / 120.0F;
}

Game::Game() = default;

const LevelDefinition& Game::level() const {
    return builtinLevels()[levelIndex_];
}

void Game::selectLevel(std::size_t index) {
    levelIndex_ = std::min(index, kLevelCount - 1);
    attempts_ = 1;
    restart();
}

void Game::restart() {
    state_ = RunState::Playing;
    playerX_ = 1.0F;
    playerY_ = 0.0F;
    verticalVelocity_ = 0.0F;
    gravityDirection_ = 1.0F;
    grounded_ = true;
    lastPortalCell_ = -1000;
    jumpBufferRemaining_ = 0.0F;
    coyoteRemaining_ = kCoyoteSeconds;
}

void Game::applyLevelChange(int direction) {
    const int count = static_cast<int>(kLevelCount);
    int next = static_cast<int>(levelIndex_) + direction;
    next = (next % count + count) % count;
    levelIndex_ = static_cast<std::size_t>(next);
    attempts_ = 1;
    restart();
}

std::uint32_t Game::hashCell(int cell, std::uint32_t salt) const {
    std::uint32_t value = static_cast<std::uint32_t>(cell) ^ level().seed ^ salt;
    value ^= value >> 16U;
    value *= 0x7feb352dU;
    value ^= value >> 15U;
    value *= 0x846ca68bU;
    value ^= value >> 16U;
    return value;
}

bool Game::spikeAt(int cell) const {
    if (cell < 8 || cell > static_cast<int>(level().length) - 5) {
        return false;
    }
    const unsigned threshold = 8U + static_cast<unsigned>(level().difficulty) * 2U;
    return (hashCell(cell, 0x51A1U) % 100U) < threshold && !padAt(cell);
}

bool Game::padAt(int cell) const {
    if (cell < 12 || level().difficulty < 2) {
        return false;
    }
    return (hashCell(cell, 0xA11DU) % 100U) < (2U + level().difficulty / 3U);
}

bool Game::gravityPortalAt(int cell) const {
    if (cell < 24 || level().difficulty < 5) {
        return false;
    }
    return (hashCell(cell, 0x6A71U) % 211U) == 0U;
}

float Game::progress() const {
    return std::clamp(playerX_ / level().length, 0.0F, 1.0F);
}

void Game::simulateStep(float dt) {
    jumpBufferRemaining_ = std::max(0.0F, jumpBufferRemaining_ - dt);
    coyoteRemaining_ = grounded_ ? kCoyoteSeconds : std::max(0.0F, coyoteRemaining_ - dt);

    if (jumpBufferRemaining_ > 0.0F && coyoteRemaining_ > 0.0F) {
        verticalVelocity_ = kJumpVelocity * gravityDirection_;
        grounded_ = false;
        jumpBufferRemaining_ = 0.0F;
        coyoteRemaining_ = 0.0F;
    }

    verticalVelocity_ -= kGravity * gravityDirection_ * dt;
    playerY_ += verticalVelocity_ * dt;
    playerX_ += kBaseHorizontalUnitsPerSecond * level().speed * dt;

    const int cell = static_cast<int>(std::floor(playerX_ + 0.35F));

    if (padAt(cell) && std::fabs(playerY_) < 0.45F) {
        verticalVelocity_ = kPadVelocity * gravityDirection_;
        grounded_ = false;
    }

    if (gravityPortalAt(cell) && cell != lastPortalCell_) {
        gravityDirection_ *= -1.0F;
        verticalVelocity_ = 4.0F * gravityDirection_;
        grounded_ = false;
        coyoteRemaining_ = 0.0F;
        lastPortalCell_ = cell;
    }

    if (gravityDirection_ > 0.0F && playerY_ <= 0.0F) {
        playerY_ = 0.0F;
        verticalVelocity_ = 0.0F;
        grounded_ = true;
    } else if (gravityDirection_ < 0.0F && playerY_ >= 6.0F) {
        playerY_ = 6.0F;
        verticalVelocity_ = 0.0F;
        grounded_ = true;
    } else {
        grounded_ = false;
    }

    const float distanceToSurface = gravityDirection_ > 0.0F ? playerY_ : 6.0F - playerY_;
    if (spikeAt(cell) && distanceToSurface < kCollisionHeight) {
        state_ = RunState::Dead;
        return;
    }

    if (playerY_ < -2.0F || playerY_ > 8.0F) {
        state_ = RunState::Dead;
        return;
    }

    if (playerX_ >= level().length) {
        playerX_ = level().length;
        state_ = RunState::Complete;
    }
}

void Game::update(float dt, const InputFrame& input) {
    if (input.previousLevelPressed) {
        applyLevelChange(-1);
        return;
    }
    if (input.nextLevelPressed) {
        applyLevelChange(1);
        return;
    }
    if (input.restartPressed || (state_ != RunState::Playing && input.jumpPressed)) {
        ++attempts_;
        restart();
        return;
    }
    if (state_ != RunState::Playing) {
        return;
    }

    if (input.jumpPressed) {
        jumpBufferRemaining_ = kJumpBufferSeconds;
    }

    float remaining = std::clamp(dt, 0.0F, 0.05F);
    while (remaining > 0.0F && state_ == RunState::Playing) {
        const float step = std::min(remaining, kMaximumStep);
        simulateStep(step);
        remaining -= step;
    }
}

}  // namespace gdu
