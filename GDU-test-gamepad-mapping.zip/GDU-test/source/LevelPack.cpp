#include "gdu/LevelPack.hpp"

namespace gdu {

const std::array<LevelDefinition, kLevelCount>& builtinLevels() {
    static const std::array<LevelDefinition, kLevelCount> levels{{
        {"level-01", "First Pulse", "azure", "01-first-pulse.ogg", 1, 1, 100, 1.000F, 98.0F, 7300},
        {"level-02", "Neon Steps", "lime", "02-neon-steps.ogg", 1, 1, 104, 1.035F, 106.0F, 7437},
        {"level-03", "Pixel Avenue", "violet", "03-pixel-avenue.ogg", 2, 2, 108, 1.070F, 114.0F, 7574},
        {"level-04", "Sky Circuit", "sky", "04-sky-circuit.ogg", 2, 2, 112, 1.105F, 122.0F, 7711},
        {"level-05", "Gravity Garden", "garden", "05-gravity-garden.ogg", 3, 3, 116, 1.140F, 130.0F, 7848},
        {"level-06", "Crystal Drive", "crystal", "06-crystal-drive.ogg", 3, 3, 120, 1.175F, 138.0F, 7985},
        {"level-07", "Voltage Run", "electric", "07-voltage-run.ogg", 4, 4, 124, 1.210F, 146.0F, 8122},
        {"level-08", "Moonlit Gears", "lunar", "08-moonlit-gears.ogg", 4, 4, 128, 1.245F, 154.0F, 8259},
        {"level-09", "Prism Break", "prism", "09-prism-break.ogg", 5, 5, 132, 1.280F, 162.0F, 8396},
        {"level-10", "Turbo Temple", "temple", "10-turbo-temple.ogg", 5, 5, 136, 1.315F, 170.0F, 8533},
        {"level-11", "Orbit Shift", "orbit", "11-orbit-shift.ogg", 6, 6, 140, 1.350F, 178.0F, 8670},
        {"level-12", "Digital Mirage", "mirage", "12-digital-mirage.ogg", 6, 6, 144, 1.385F, 186.0F, 8807},
        {"level-13", "Frost Reactor", "frost", "13-frost-reactor.ogg", 7, 7, 148, 1.420F, 194.0F, 8944},
        {"level-14", "Solar Fracture", "solar", "14-solar-fracture.ogg", 7, 7, 152, 1.455F, 202.0F, 9081},
        {"level-15", "Phantom Grid", "phantom", "15-phantom-grid.ogg", 8, 8, 156, 1.490F, 210.0F, 9218},
        {"level-16", "Quantum Rush", "quantum", "16-quantum-rush.ogg", 8, 8, 160, 1.525F, 218.0F, 9355},
        {"level-17", "Nova Collapse", "nova", "17-nova-collapse.ogg", 9, 9, 164, 1.560F, 226.0F, 9492},
        {"level-18", "Chromatic Storm", "storm", "18-chromatic-storm.ogg", 9, 9, 168, 1.595F, 234.0F, 9629},
        {"level-19", "Void Engine", "void", "19-void-engine.ogg", 10, 10, 172, 1.630F, 242.0F, 9766},
        {"level-20", "Hypernova", "hyper", "20-hypernova.ogg", 10, 10, 176, 1.665F, 250.0F, 9903},
        {"level-21", "Final Resonance", "finale", "21-final-resonance.ogg", 10, 10, 180, 1.700F, 258.0F, 10040},
    }};
    return levels;
}

}  // namespace gdu
