# GDU original music

This folder contains 21 short original electronic loops generated specifically for GDU. Each level references one `.ogg` file in `assets/levels/pack.json`.

You may replace a track with your own `.ogg`, `.mp3` or `.wav` file. Keep the filename in the level's `music` property synchronized. Only use music you created or are allowed to redistribute.
