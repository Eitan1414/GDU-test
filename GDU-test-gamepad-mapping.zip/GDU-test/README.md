# GDU — Pulse Rift

GDU is an original rhythm-platformer project targeting Wii U homebrew. It uses an original name, level pack, interface, music and generated shapes; it does not redistribute Geometry Dash or Super Mario Maker code, graphics, levels, music or branding.

## Alpha contents

- Wii U C++17 gameplay core built with devkitPro/wut.
- Native level-browser logic for all 21 original levels.
- Jump buffering, coyote time and 120 Hz gameplay substeps for consistent input.
- 21 original electronic tracks, one per level.
- Original 21-level visual browser with difficulty, stars, BPM, track and saved progress.
- GamePad-first browser editor laid out specifically for 854×480.
- Touch painting, selection/movement, continuous erase, two-finger/pan tool, timeline navigation, undo/redo and instant testing.
- Blocks, platforms, spikes, saws, pads, orbs, gravity portals, speed portals, start markers, checkpoints and finish markers.
- JSON import/export and local saves.
- GitHub Actions workflow producing `gdu.rpx` and an SD-card artifact.

## Try the complete interface

From the repository root:

```bash
python -m http.server 8000
```

Open `http://localhost:8000/editor/`.

The **JOUER** tab presents the 21 original levels in an arcade carousel. The **CRÉER** tab opens the GamePad editor.

## Wii U and GamePad controls

### Gameplay

- **A:** jump and interact with jump orbs/contextual transformations
- **Start / Plus:** open or close the pause menu
- **Select / Minus:** open the tutorial in the GamePad interface

### Editor

- **Stylus / GamePad touch:** select an item and place, move or erase it on the level map
- **A:** launch the level test
- **B:** undo the latest modification
- **D-pad Right / Left:** next or previous item page
- **R / L:** next or previous item category
- **Start / Plus:** open the pause menu
- **Select / Minus:** open the editor tutorial

The editor intentionally does not place objects with A or erase with B. Level construction remains touch/stylus-only.

## Build locally

Install devkitPro and the `wiiu-dev` group, then run:

```bash
mkdir -p build
cd build
/opt/devkitpro/portlibs/wiiu/bin/powerpc-eabi-cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build .
```

The result is `build/gdu.rpx`.

## Status of the native editor

The complete GamePad interaction and UI are implemented in the browser prototype and documented in `docs/GAMEPAD_EDITOR.md`. The current RPX still renders through the wut development console. A GX2 or Wii U SDL2 visual renderer, native touch-coordinate wiring and native OGG playback remain the next integration milestone.

## Repository layout

- `source/`, `include/`: Wii U runtime
- `assets/levels/pack.json`: 21 original levels
- `assets/music/`: 21 original tracks
- `editor/`: level browser, GamePad editor and playtest
- `docs/GAMEPAD_EDITOR.md`: touch/controller design and performance decisions
- `tools/validate_levels.py`: pack validation
- `.github/workflows/build-wiiu.yml`: automated build
