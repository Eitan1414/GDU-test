#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace gdu {

struct LevelDefinition {
    const char* id;
    const char* name;
    const char* theme;
    const char* music;
    std::uint8_t difficulty;
    std::uint8_t stars;
    std::uint16_t bpm;
    float speed;
    float length;
    std::uint32_t seed;
};

constexpr std::size_t kLevelCount = 21;

const std::array<LevelDefinition, kLevelCount>& builtinLevels();

}  // namespace gdu
