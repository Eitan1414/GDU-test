#pragma once

#include <cstddef>
#include <cstdint>

#include "gdu/LevelPack.hpp"

namespace gdu {

enum class RunState {
    Playing,
    Dead,
    Complete,
};

struct InputFrame {
    bool jumpPressed{false};
    bool restartPressed{false};
    bool previousLevelPressed{false};
    bool nextLevelPressed{false};
};

class Game {
public:
    Game();

    void update(float dt, const InputFrame& input);
    void restart();
    void selectLevel(std::size_t index);

    const LevelDefinition& level() const;
    std::size_t levelIndex() const { return levelIndex_; }
    RunState state() const { return state_; }
    float playerX() const { return playerX_; }
    float playerY() const { return playerY_; }
    float progress() const;
    unsigned attempts() const { return attempts_; }

    bool spikeAt(int cell) const;
    bool padAt(int cell) const;
    bool gravityPortalAt(int cell) const;

private:
    std::uint32_t hashCell(int cell, std::uint32_t salt) const;
    void applyLevelChange(int direction);
    void simulateStep(float dt);

    std::size_t levelIndex_{0};
    RunState state_{RunState::Playing};
    float playerX_{1.0F};
    float playerY_{0.0F};
    float verticalVelocity_{0.0F};
    float gravityDirection_{1.0F};
    bool grounded_{true};
    unsigned attempts_{1};
    int lastPortalCell_{-1000};
    float jumpBufferRemaining_{0.0F};
    float coyoteRemaining_{0.08F};
};

}  // namespace gdu
