# GDU Pulse Rift Studio

Start a local server from the repository root:

```bash
python -m http.server 8000
```

Open `http://localhost:8000/editor/`.

## Included screens

- A 21-level arcade browser with original cards, difficulty, stars, BPM, music and saved completion percentage.
- A touch-first level editor designed around an 854×480 GamePad display.
- A fixed-step playtest with jump buffering, coyote time, practice checkpoints, spatially indexed collisions and instant restart.
- A GamePad pause menu and a built-in controls tutorial.

## Editor workflow

- Use the stylus or touch screen to select a category and item.
- Touch or drag on the map to place items.
- Use **Selection** to move an object, **Gomme** to erase, and **Déplacer** or two fingers to pan.
- Use the lower timeline to jump through long levels.

## GamePad shortcuts

- **A:** test the level.
- **B:** undo the latest modification.
- **D-pad Left/Right:** previous or next item page.
- **L/R:** previous or next item category.
- **Start/Plus:** pause menu.
- **Select/Minus:** controls tutorial.

Object placement and erasing are touch/stylus actions only; A and B do not alter the map directly.

## Gameplay

- **A:** jump, restart after death and activate jump orbs/contextual transformations.
- **Start/Plus:** pause menu.
- **Select/Minus:** tutorial.

## Music

- **Lire / Pause** previews the current level track.
- **Stop** resets the track.
- **Volume** is remembered locally.
- **Importer ma musique** previews a personal `.ogg`, `.mp3` or `.wav` file.

A browser-imported personal track is temporary. Copy it into `assets/music/` and preserve its filename in the level JSON before packaging the Wii U build.
