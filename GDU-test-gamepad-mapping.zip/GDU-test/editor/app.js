'use strict';

const BASE_GRID = 32;
const MAX_HISTORY = 120;
const FIXED_STEP = 1 / 120;
const MAX_FRAME = 0.05;
const PLAYER_SIZE = 0.72;
const ITEM_PAGE_SIZE = 2;

const THEMES = {
  azure:   { color: '#2678ff', glow: '#255ee8', sky: '#101d4f', ground: '#182965' },
  lime:    { color: '#69dc45', glow: '#42bd6a', sky: '#102f36', ground: '#174b49' },
  violet:  { color: '#8b5cff', glow: '#6c42dc', sky: '#28164d', ground: '#3d226c' },
  sky:     { color: '#53c9ff', glow: '#2a91ee', sky: '#133a60', ground: '#215477' },
  garden:  { color: '#63e084', glow: '#2aaa67', sky: '#163f36', ground: '#275d45' },
  crystal: { color: '#73efff', glow: '#48abd7', sky: '#18395b', ground: '#245f78' },
  electric:{ color: '#fff15d', glow: '#d18f22', sky: '#44351a', ground: '#675126' },
  lunar:   { color: '#8393ff', glow: '#5061d5', sky: '#171c45', ground: '#29315f' },
  prism:   { color: '#ff65d8', glow: '#7e63ff', sky: '#33194c', ground: '#50266d' },
  temple:  { color: '#ffae52', glow: '#cc6135', sky: '#4a2517', ground: '#693522' },
  orbit:   { color: '#5ee8e2', glow: '#387ac4', sky: '#112d49', ground: '#204663' },
  mirage:  { color: '#f58bd8', glow: '#8c6bd5', sky: '#382242', ground: '#52305d' },
  frost:   { color: '#b7f7ff', glow: '#65bbdf', sky: '#173b55', ground: '#285a74' },
  solar:   { color: '#ffda55', glow: '#ff6b39', sky: '#4f2316', ground: '#71341c' },
  phantom: { color: '#a486ff', glow: '#5a4cbf', sky: '#201944', ground: '#34285e' },
  quantum: { color: '#47f4bd', glow: '#317cdf', sky: '#10344d', ground: '#19526a' },
  nova:    { color: '#ff7a61', glow: '#c84175', sky: '#431d36', ground: '#622945' },
  storm:   { color: '#70b7ff', glow: '#7158d6', sky: '#202548', ground: '#303762' },
  void:    { color: '#9e76ff', glow: '#462ca1', sky: '#120d2d', ground: '#23174a' },
  hyper:   { color: '#ff5cae', glow: '#5e73ff', sky: '#321549', ground: '#482366' },
  finale:  { color: '#5ffff2', glow: '#ff5fcf', sky: '#261947', ground: '#34306e' },
  neon:    { color: '#5ee8ff', glow: '#6d5cff', sky: '#151b43', ground: '#242c5d' },
};

const PALETTES = {
  terrain: [
    { id: 'block', type: 'block', label: 'Bloc', preview: 'block', preset: { w: 1, h: 1, layer: 0 } },
    { id: 'platform', type: 'block', label: 'Plateforme', preview: 'platform', preset: { w: 3, h: 1, layer: 0 } },
  ],
  hazards: [
    { id: 'spike', type: 'spike', label: 'Pic', preview: 'spike', preset: { layer: 0 } },
    { id: 'saw', type: 'saw', label: 'Scie', preview: 'saw', preset: { layer: 0, radius: 0.45 } },
  ],
  mechanics: [
    { id: 'jump_pad', type: 'jump_pad', label: 'Pad', preview: 'jump_pad', preset: { layer: 1 } },
    { id: 'orb', type: 'orb', label: 'Orbe', preview: 'orb', preset: { layer: 1 } },
    { id: 'gravity_portal', type: 'gravity_portal', label: 'Gravité', preview: 'gravity_portal', preset: { layer: 1 } },
    { id: 'speed_portal', type: 'speed_portal', label: 'Vitesse', preview: 'speed_portal', preset: { layer: 1, speed: 1.25 } },
  ],
  markers: [
    { id: 'start_position', type: 'start_position', label: 'Départ', preview: 'start_position', preset: { layer: 2 } },
    { id: 'checkpoint', type: 'checkpoint', label: 'Point', preview: 'checkpoint', preset: { layer: 2 } },
    { id: 'finish', type: 'finish', label: 'Arrivée', preview: 'finish', preset: { layer: 2 } },
  ],
  tools: [
    { id: 'select', label: 'Sélection', preview: 'select', utility: true },
    { id: 'erase', label: 'Gomme', preview: 'erase', utility: true },
    { id: 'pan', label: 'Déplacer', preview: 'pan', utility: true },
    { id: 'grid', label: 'Grille', preview: 'grid', utility: true },
  ],
};

const fallbackNames = [
  'First Pulse', 'Neon Steps', 'Pixel Avenue', 'Sky Circuit', 'Gravity Garden', 'Crystal Drive', 'Voltage Run',
  'Moonlit Gears', 'Prism Break', 'Turbo Temple', 'Orbit Shift', 'Digital Mirage', 'Frost Reactor', 'Solar Fracture',
  'Phantom Grid', 'Quantum Rush', 'Nova Collapse', 'Chromatic Storm', 'Void Engine', 'Hypernova', 'Final Resonance',
];
const fallbackThemes = Object.keys(THEMES).filter((key) => key !== 'neon').slice(0, 21);

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const dom = {
  libraryView: $('#libraryView'), editorView: $('#editorView'), libraryTab: $('#libraryTab'), editorTab: $('#editorTab'),
  homeBtn: $('#homeBtn'), previousLevelBtn: $('#previousLevelBtn'), nextLevelBtn: $('#nextLevelBtn'), levelWheel: $('#levelWheel'),
  levelDots: $('#levelDots'), levelNumber: $('#levelNumber'), levelBpm: $('#levelBpm'), levelMusic: $('#levelMusic'),
  levelProgressFill: $('#levelProgressFill'), practiceBtn: $('#practiceBtn'), playLevelBtn: $('#playLevelBtn'), editLevelBtn: $('#editLevelBtn'),
  gamepadStatus: $('#gamepadStatus'), globalSaveBtn: $('#globalSaveBtn'), globalExportBtn: $('#globalExportBtn'), importInput: $('#importInput'),
  backToLibraryBtn: $('#backToLibraryBtn'), editorPreviousLevel: $('#editorPreviousLevel'), editorNextLevel: $('#editorNextLevel'),
  editorLevelTitle: $('#editorLevelTitle'), editorLevelSubtitle: $('#editorLevelSubtitle'), levelSettingsBtn: $('#levelSettingsBtn'),
  undoBtn: $('#undoBtn'), redoBtn: $('#redoBtn'), zoomOutBtn: $('#zoomOutBtn'), zoomInBtn: $('#zoomInBtn'), testBtn: $('#testBtn'),
  canvasWrap: $('#canvasWrap'), editorCanvas: $('#editorCanvas'), cameraRange: $('#cameraRange'), statusText: $('#statusText'), cursorText: $('#cursorText'),
  categoryTabs: $('#categoryTabs'), objectTray: $('#objectTray'), trayPrevious: $('#trayPrevious'), trayNext: $('#trayNext'), itemPageLabel: $('#itemPageLabel'),
  settingsSheet: $('#settingsSheet'), settingsLevelId: $('#settingsLevelId'), closeSettingsBtn: $('#closeSettingsBtn'), sheetBackdrop: $('#sheetBackdrop'),
  levelName: $('#levelName'), levelLength: $('#levelLength'), levelSpeed: $('#levelSpeed'), levelSelect: $('#levelSelect'),
  musicSelect: $('#musicSelect'), musicPlayBtn: $('#musicPlayBtn'), musicStopBtn: $('#musicStopBtn'), musicVolume: $('#musicVolume'),
  musicImportInput: $('#musicImportInput'), musicStatus: $('#musicStatus'), saveBtn: $('#saveBtn'), exportBtn: $('#exportBtn'), clearBtn: $('#clearBtn'), validation: $('#validation'),
  testOverlay: $('#testOverlay'), testCanvas: $('#testCanvas'), closeTestBtn: $('#closeTestBtn'), testTitle: $('#testTitle'),
  practiceToggle: $('#practiceToggle'), testMusicToggle: $('#testMusicToggle'), restartTestBtn: $('#restartTestBtn'),
  testMusicLabel: $('#testMusicLabel'), testHelp: $('#testHelp'), testAttempt: $('#testAttempt'), musicPlayer: $('#musicPlayer'),
  pauseOverlay: $('#pauseOverlay'), resumePauseBtn: $('#resumePauseBtn'), savePauseBtn: $('#savePauseBtn'), settingsPauseBtn: $('#settingsPauseBtn'), leaveEditorPauseBtn: $('#leaveEditorPauseBtn'),
  tutorialOverlay: $('#tutorialOverlay'), closeTutorialBtn: $('#closeTutorialBtn'),
};
const ectx = dom.editorCanvas.getContext('2d', { alpha: false });
const tctx = dom.testCanvas.getContext('2d', { alpha: false });

let pack = null;
let currentIndex = 0;
let currentView = 'library';
let practiceSelected = false;
let currentCategory = 'terrain';
let currentItemPage = 0;
let activeToolId = 'block';
let history = [];
let future = [];
let selectedObjectIndex = -1;
let cameraX = 0;
let editorZoom = 1;
let editorCursor = { x: 4, y: 0 };
let showGrid = true;
let editorDirty = true;
let editorMetrics = { width: 854, height: 280, dpr: 1 };
let testMetrics = { width: 854, height: 391, dpr: 1 };
let pointerState = { pointers: new Map(), mode: null, startX: 0, startCamera: 0, lastCell: '', moved: false };
let testState = null;
let testAnimationId = 0;
let currentMusicUrl = '';
let importedMusicUrls = new Map();
let gamepadPreviousButtons = [];
let gamepadAxisCooldown = 0;
let uiLastTime = performance.now();
let resumeMusicAfterModal = false;

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function clamp(value, minimum, maximum) { return Math.min(maximum, Math.max(minimum, value)); }
function wrapIndex(index, length) { return (index % length + length) % length; }
function currentLevel() { return pack?.levels?.[currentIndex]; }
function currentTheme() { return THEMES[currentLevel()?.theme] || THEMES.neon; }
function difficultyLabel(value) {
  if (value <= 1) return 'DÉCOUVERTE';
  if (value <= 3) return 'RYTHMÉ';
  if (value <= 5) return 'TECHNIQUE';
  if (value <= 7) return 'EXPERT';
  if (value <= 9) return 'EXTRÊME';
  return 'RESONANCE';
}
function difficultyGlyph(value) { return ['•', '◆', '▲', '✦', '⚡', '✹'][clamp(Math.ceil(value / 2) - 1, 0, 5)]; }
function progressStore() {
  try { return JSON.parse(localStorage.getItem('gdu-progress') || '{}'); } catch { return {}; }
}
function updateStoredProgress(levelId, value) {
  const progress = progressStore();
  progress[levelId] = Math.max(Number(progress[levelId] || 0), value);
  localStorage.setItem('gdu-progress', JSON.stringify(progress));
}

function makeFallbackPack() {
  return {
    schema_version: 2, game: 'GDU', title: 'Pulse Rift', grid_size: BASE_GRID,
    levels: fallbackNames.map((name, index) => ({
      id: `level-${String(index + 1).padStart(2, '0')}`, order: index + 1, name, theme: fallbackThemes[index] || 'neon',
      difficulty: Math.min(10, 1 + Math.floor(index / 2)), stars: Math.min(10, 1 + Math.floor(index / 2)),
      bpm: 100 + index * 4, speed: 1 + index * 0.035, length: 98 + index * 8, seed: 7300 + index * 137,
      music: `${String(index + 1).padStart(2, '0')}-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}.ogg`,
      objects: [{ type: 'finish', x: 96 + index * 8, y: 0, layer: 2 }],
    })),
  };
}

async function loadPack() {
  try {
    const response = await fetch('../assets/levels/pack.json');
    if (!response.ok) throw new Error('pack.json indisponible');
    pack = await response.json();
  } catch {
    pack = makeFallbackPack();
  }
  const saved = localStorage.getItem('gdu-level-pack');
  if (saved) {
    try {
      const candidate = JSON.parse(saved);
      if (Array.isArray(candidate.levels) && candidate.levels.length) pack = candidate;
    } catch { /* ignore invalid local copy */ }
  }
  normalizePack();
  refreshLevelSelect();
  loadLevel(0, false);
  showView('library');
}

function normalizePack() {
  pack.schema_version = Math.max(2, Number(pack.schema_version || 1));
  pack.grid_size = Number(pack.grid_size || BASE_GRID);
  pack.levels.forEach((level, index) => {
    level.id ||= `level-${String(index + 1).padStart(2, '0')}`;
    level.order = index + 1;
    level.name ||= `Niveau ${index + 1}`;
    level.theme ||= fallbackThemes[index] || 'neon';
    level.difficulty = clamp(Number(level.difficulty || 1), 1, 10);
    level.stars = clamp(Number(level.stars || level.difficulty), 1, 10);
    level.bpm = Number(level.bpm || 100 + index * 4);
    level.speed = Number(level.speed || 1);
    level.length = Math.max(40, Number(level.length || 100));
    level.objects = Array.isArray(level.objects) ? level.objects : [];
  });
}

function showView(view) {
  currentView = view;
  dom.libraryView.classList.toggle('active-view', view === 'library');
  dom.editorView.classList.toggle('active-view', view === 'editor');
  dom.libraryTab.classList.toggle('active', view === 'library');
  dom.editorTab.classList.toggle('active', view === 'editor');
  closeSettings();
  if (view === 'library') renderLibrary();
  if (view === 'editor') {
    syncEditorHeader();
    renderObjectTray();
    requestEditorDraw();
    setTimeout(resizeEditorCanvas, 0);
  }
}

function selectRelativeLevel(direction) {
  loadLevel(wrapIndex(currentIndex + direction, pack.levels.length), true);
}

function loadLevel(index, keepView = true) {
  stopMusic();
  currentIndex = wrapIndex(Number(index), pack.levels.length);
  history = [];
  future = [];
  selectedObjectIndex = -1;
  cameraX = 0;
  editorCursor = { x: 4, y: 0 };
  syncSettingsInputs();
  renderLibrary();
  syncEditorHeader();
  updateCameraRange();
  requestEditorDraw();
  validateCurrentLevel();
  if (!keepView) return;
}

function renderLibrary() {
  if (!pack) return;
  const level = currentLevel();
  const theme = currentTheme();
  dom.libraryView.style.setProperty('--theme-glow', theme.glow);
  dom.levelWheel.innerHTML = '';
  for (let offset = -2; offset <= 2; offset += 1) {
    const index = wrapIndex(currentIndex + offset, pack.levels.length);
    const item = pack.levels[index];
    const itemTheme = THEMES[item.theme] || THEMES.neon;
    const card = document.createElement('article');
    card.className = `level-card ${offset === 0 ? 'center' : Math.abs(offset) === 1 ? 'side' : 'far'}`;
    card.style.setProperty('--card-color', itemTheme.color);
    card.style.setProperty('--tilt', `${offset < 0 ? 18 : -18}deg`);
    card.dataset.index = String(index);
    card.innerHTML = `
      <div class="card-topline"><span>${String(item.order).padStart(2, '0')}</span><span>${difficultyLabel(item.difficulty)}</span></div>
      <div class="difficulty-emblem"><span>${difficultyGlyph(item.difficulty)}</span></div>
      <div class="card-copy"><h2>${escapeHtml(item.name)}</h2><p><span class="stars">${'★'.repeat(Math.min(5, Math.ceil(item.stars / 2)))}</span> · ${item.length} mesures</p></div>`;
    card.addEventListener('click', () => {
      if (index === currentIndex) startTest(practiceSelected);
      else loadLevel(index, true);
    });
    dom.levelWheel.append(card);
  }
  dom.levelDots.innerHTML = '';
  pack.levels.forEach((item, index) => {
    const dot = document.createElement('button');
    dot.className = `level-dot ${index === currentIndex ? 'active' : ''}`;
    dot.title = item.name;
    dot.addEventListener('click', () => loadLevel(index, true));
    dom.levelDots.append(dot);
  });
  const progress = Number(progressStore()[level.id] || 0);
  dom.levelNumber.textContent = `NIVEAU ${String(level.order).padStart(2, '0')} / ${pack.levels.length}`;
  dom.levelBpm.textContent = `${level.bpm} BPM`;
  dom.levelMusic.textContent = level.music || 'SANS MUSIQUE';
  dom.levelProgressFill.style.width = `${clamp(progress, 0, 100)}%`;
  dom.practiceBtn.classList.toggle('active', practiceSelected);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character]));
}

function syncEditorHeader() {
  if (!pack) return;
  const level = currentLevel();
  dom.editorLevelTitle.textContent = level.name;
  dom.editorLevelSubtitle.textContent = `Niveau ${String(level.order).padStart(2, '0')} · ${level.objects.length} objets`;
  dom.settingsLevelId.textContent = level.id;
  dom.undoBtn.disabled = history.length === 0;
  dom.redoBtn.disabled = future.length === 0;
}

function refreshLevelSelect() {
  dom.levelSelect.innerHTML = '';
  pack.levels.forEach((level, index) => {
    const option = document.createElement('option');
    option.value = String(index);
    option.textContent = `${String(index + 1).padStart(2, '0')} · ${level.name}`;
    dom.levelSelect.append(option);
  });
}

function syncSettingsInputs() {
  if (!pack) return;
  const level = currentLevel();
  refreshLevelSelect();
  dom.levelSelect.value = String(currentIndex);
  dom.levelName.value = level.name;
  dom.levelLength.value = String(level.length);
  dom.levelSpeed.value = String(level.speed);
  refreshMusicSelect();
  loadCurrentMusic(false, false);
}

function openSettings() {
  syncSettingsInputs();
  validateCurrentLevel();
  dom.settingsSheet.classList.add('open');
  dom.sheetBackdrop.classList.add('open');
  dom.settingsSheet.setAttribute('aria-hidden', 'false');
}
function closeSettings() {
  dom.settingsSheet.classList.remove('open');
  dom.sheetBackdrop.classList.remove('open');
  dom.settingsSheet.setAttribute('aria-hidden', 'true');
}

function openPauseMenu() {
  resumeMusicAfterModal = Boolean(testState && !dom.musicPlayer.paused);
  if (dom.tutorialOverlay.classList.contains('open')) closeTutorial();
  dom.pauseOverlay.classList.add('open');
  dom.pauseOverlay.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');
  if (testState) { testState.paused = true; dom.musicPlayer.pause(); }
}
function closePauseMenu() {
  dom.pauseOverlay.classList.remove('open');
  dom.pauseOverlay.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('modal-open');
  if (testState) { testState.paused = false; testState.lastTime = performance.now(); if (resumeMusicAfterModal) dom.musicPlayer.play().catch(() => {}); }
  resumeMusicAfterModal = false;
}
function togglePauseMenu() {
  dom.pauseOverlay.classList.contains('open') ? closePauseMenu() : openPauseMenu();
}
function openTutorial() {
  const shouldResumeMusic = resumeMusicAfterModal || Boolean(testState && !dom.musicPlayer.paused);
  if (dom.pauseOverlay.classList.contains('open')) closePauseMenu();
  resumeMusicAfterModal = shouldResumeMusic || Boolean(testState && !dom.musicPlayer.paused);
  dom.tutorialOverlay.classList.add('open');
  dom.tutorialOverlay.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');
  if (testState) { testState.paused = true; dom.musicPlayer.pause(); }
}
function closeTutorial() {
  dom.tutorialOverlay.classList.remove('open');
  dom.tutorialOverlay.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('modal-open');
  if (testState) { testState.paused = false; testState.lastTime = performance.now(); if (resumeMusicAfterModal) dom.musicPlayer.play().catch(() => {}); }
  resumeMusicAfterModal = false;
}

function currentTool() {
  return Object.values(PALETTES).flat().find((entry) => entry.id === activeToolId) || PALETTES.terrain[0];
}

function itemPageCount() {
  return Math.max(1, Math.ceil(PALETTES[currentCategory].length / ITEM_PAGE_SIZE));
}

function renderObjectTray() {
  const list = PALETTES[currentCategory];
  currentItemPage = wrapIndex(currentItemPage, Math.max(1, Math.ceil(list.length / ITEM_PAGE_SIZE)));
  const start = currentItemPage * ITEM_PAGE_SIZE;
  const pageItems = list.slice(start, start + ITEM_PAGE_SIZE);
  dom.objectTray.innerHTML = '';
  pageItems.forEach((entry) => {
    const button = document.createElement('button');
    button.className = `object-button ${entry.id === activeToolId ? 'active' : ''}`;
    button.dataset.tool = entry.id;
    button.innerHTML = `<span class="object-preview preview-${entry.preview}"></span><small>${entry.label}</small>`;
    button.addEventListener('click', () => setTool(entry.id));
    dom.objectTray.append(button);
  });
  dom.itemPageLabel.textContent = `PAGE ${currentItemPage + 1} / ${itemPageCount()}`;
}

function setCategory(category) {
  if (!PALETTES[category]) return;
  currentCategory = category;
  currentItemPage = 0;
  $$('#categoryTabs [data-category]').forEach((button) => button.classList.toggle('active', button.dataset.category === category));
  if (!PALETTES[category].some((entry) => entry.id === activeToolId)) activeToolId = PALETTES[category][0].id;
  renderObjectTray();
  dom.statusText.textContent = `Palette : ${category}`;
}

function setTool(toolId) {
  const entry = Object.values(PALETTES).flat().find((item) => item.id === toolId);
  if (!entry) return;
  activeToolId = toolId;
  const category = Object.entries(PALETTES).find(([, values]) => values.some((item) => item.id === toolId))?.[0];
  if (category && category !== currentCategory) { currentCategory = category; currentItemPage = 0; }
  if (toolId === 'grid') {
    showGrid = !showGrid;
    activeToolId = 'select';
  }
  $$('#categoryTabs [data-category]').forEach((button) => button.classList.toggle('active', button.dataset.category === currentCategory));
  renderObjectTray();
  dom.statusText.textContent = `Outil : ${entry.label}`;
  requestEditorDraw();
}

function cycleTool(direction) {
  const list = PALETTES[currentCategory];
  const index = Math.max(0, list.findIndex((item) => item.id === activeToolId));
  setTool(list[wrapIndex(index + direction, list.length)].id);
  dom.objectTray.querySelector('.active')?.scrollIntoView({ inline: 'center', behavior: 'smooth' });
}
function cycleItemPage(direction = 1) {
  const count = itemPageCount();
  currentItemPage = wrapIndex(currentItemPage + direction, count);
  const list = PALETTES[currentCategory];
  const firstOnPage = list[currentItemPage * ITEM_PAGE_SIZE];
  if (firstOnPage) activeToolId = firstOnPage.id;
  renderObjectTray();
  dom.statusText.textContent = `Page d’objets ${currentItemPage + 1} / ${count}`;
}

function cycleCategory(direction = 1) {
  const categories = Object.keys(PALETTES);
  setCategory(categories[wrapIndex(categories.indexOf(currentCategory) + direction, categories.length)]);
}

function snapshot() {
  history.push(clone(currentLevel()));
  if (history.length > MAX_HISTORY) history.shift();
  future = [];
  syncEditorHeader();
}
function restoreLevel(level) {
  pack.levels[currentIndex] = clone(level);
  selectedObjectIndex = -1;
  syncSettingsInputs();
  syncEditorHeader();
  validateCurrentLevel();
  requestEditorDraw();
}
function undo() {
  if (!history.length) return;
  future.push(clone(currentLevel()));
  restoreLevel(history.pop());
}
function redo() {
  if (!future.length) return;
  history.push(clone(currentLevel()));
  restoreLevel(future.pop());
}

function resizeCanvas(canvas, context, parent, metricsTarget) {
  const rect = parent.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const width = Math.max(1, Math.floor(rect.width));
  const height = Math.max(1, Math.floor(rect.height));
  const actualWidth = Math.floor(width * dpr);
  const actualHeight = Math.floor(height * dpr);
  if (canvas.width !== actualWidth || canvas.height !== actualHeight) {
    canvas.width = actualWidth;
    canvas.height = actualHeight;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
  }
  metricsTarget.width = width;
  metricsTarget.height = height;
  metricsTarget.dpr = dpr;
  context.setTransform(dpr, 0, 0, dpr, 0, 0);
}
function resizeEditorCanvas() {
  if (currentView !== 'editor') return;
  resizeCanvas(dom.editorCanvas, ectx, dom.canvasWrap, editorMetrics);
  updateCameraRange();
  requestEditorDraw();
}
function resizeTestCanvas() {
  if (!dom.testOverlay.classList.contains('open')) return;
  resizeCanvas(dom.testCanvas, tctx, dom.testCanvas, testMetrics);
}

function editorGridPixels() { return BASE_GRID * editorZoom; }
function editorGroundY() { return editorMetrics.height - 50; }
function maxCameraX() {
  const visible = editorMetrics.width / editorGridPixels();
  return Math.max(0, Number(currentLevel()?.length || 40) + 4 - visible);
}
function setCamera(value) {
  cameraX = clamp(value, 0, maxCameraX());
  updateCameraRange();
  requestEditorDraw();
}
function updateCameraRange() {
  const maximum = maxCameraX();
  dom.cameraRange.max = '1000';
  dom.cameraRange.value = maximum > 0 ? String(Math.round((cameraX / maximum) * 1000)) : '0';
}
function zoomEditor(factor) {
  const centerWorld = cameraX + editorMetrics.width / editorGridPixels() / 2;
  editorZoom = clamp(editorZoom * factor, 0.6, 1.85);
  setCamera(centerWorld - editorMetrics.width / editorGridPixels() / 2);
  dom.statusText.textContent = `Zoom : ${Math.round(editorZoom * 100)} %`;
}

function requestEditorDraw() { editorDirty = true; }
function clearCanvas(context, canvas, metrics) {
  context.setTransform(1, 0, 0, 1, 0, 0);
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.setTransform(metrics.dpr, 0, 0, metrics.dpr, 0, 0);
}
function objectRect(obj, gridPixels = editorGridPixels(), groundY = editorGroundY(), camera = cameraX) {
  const width = Number(obj.w || 1) * gridPixels;
  const height = Number(obj.h || 1) * gridPixels;
  return { x: (Number(obj.x) - camera) * gridPixels, y: groundY - (Number(obj.y) + Number(obj.h || 1)) * gridPixels, w: width, h: height };
}

function drawGrid(context, metrics, gridPixels, camera, theme, groundY) {
  context.fillStyle = theme.sky;
  context.fillRect(0, 0, metrics.width, metrics.height);
  const major = gridPixels * 4;
  if (showGrid && gridPixels >= 18) {
    context.lineWidth = 1;
    const startX = -((camera * gridPixels) % gridPixels);
    for (let x = startX; x <= metrics.width; x += gridPixels) {
      const worldCell = Math.round(camera + x / gridPixels);
      context.strokeStyle = worldCell % 4 === 0 ? '#ffffff1c' : '#ffffff0b';
      context.beginPath(); context.moveTo(Math.round(x) + .5, 0); context.lineTo(Math.round(x) + .5, groundY); context.stroke();
    }
    for (let y = groundY; y >= 0; y -= gridPixels) {
      const row = Math.round((groundY - y) / gridPixels);
      context.strokeStyle = row % 4 === 0 ? '#ffffff1c' : '#ffffff0b';
      context.beginPath(); context.moveTo(0, Math.round(y) + .5); context.lineTo(metrics.width, Math.round(y) + .5); context.stroke();
    }
    context.strokeStyle = '#ffffff10';
    for (let x = -((camera * gridPixels) % major); x <= metrics.width; x += major) {
      context.fillStyle = '#ffffff42'; context.font = '9px system-ui';
      context.fillText(String(Math.max(0, Math.round(camera + x / gridPixels))), x + 3, 12);
    }
  }
  context.fillStyle = theme.ground;
  context.fillRect(0, groundY, metrics.width, metrics.height - groundY);
  context.fillStyle = `${theme.color}44`;
  context.fillRect(0, groundY, metrics.width, 4);
}

function drawObject(context, obj, rect, selected = false, alpha = 1, viewportWidth = editorMetrics.width) {
  if (rect.x + rect.w < -60 || rect.x > viewportWidth + 60) return;
  context.save();
  context.globalAlpha = alpha;
  const pad = Math.max(2, Math.min(5, rect.w * .08));
  switch (obj.type) {
    case 'block':
      context.fillStyle = '#765cff'; context.fillRect(rect.x + pad, rect.y + pad, rect.w - pad * 2, rect.h - pad * 2);
      context.strokeStyle = '#b9aaff'; context.lineWidth = Math.max(2, rect.w * .04); context.strokeRect(rect.x + pad * 1.5, rect.y + pad * 1.5, rect.w - pad * 3, rect.h - pad * 3); break;
    case 'spike':
      context.fillStyle = '#ff5d86'; context.beginPath(); context.moveTo(rect.x + 2, rect.y + rect.h - 2); context.lineTo(rect.x + rect.w / 2, rect.y + 2); context.lineTo(rect.x + rect.w - 2, rect.y + rect.h - 2); context.closePath(); context.fill();
      context.strokeStyle = '#ffd2dc'; context.lineWidth = 2; context.stroke(); break;
    case 'saw': {
      const radius = Math.min(rect.w, rect.h) * .43; const cx = rect.x + rect.w / 2; const cy = rect.y + rect.h / 2;
      context.fillStyle = '#ffae56'; context.beginPath();
      for (let i = 0; i < 24; i += 1) { const angle = (Math.PI * 2 * i) / 24; const r = i % 2 ? radius * .7 : radius; context.lineTo(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r); }
      context.closePath(); context.fill(); context.fillStyle = '#5b2d32'; context.beginPath(); context.arc(cx, cy, radius * .25, 0, Math.PI * 2); context.fill(); break;
    }
    case 'jump_pad':
      context.fillStyle = '#ffe65f'; context.fillRect(rect.x + 4, rect.y + rect.h - 12, rect.w - 8, 8); context.fillStyle = '#fff3a8'; context.fillRect(rect.x + 9, rect.y + rect.h - 17, rect.w - 18, 4); break;
    case 'orb':
      context.strokeStyle = '#56efb1'; context.lineWidth = 6; context.beginPath(); context.arc(rect.x + rect.w / 2, rect.y + rect.h / 2, Math.min(rect.w, rect.h) * .3, 0, Math.PI * 2); context.stroke(); break;
    case 'gravity_portal':
    case 'speed_portal':
      context.strokeStyle = obj.type === 'gravity_portal' ? '#ff70ec' : '#5ee9ff'; context.lineWidth = 6; context.beginPath(); context.ellipse(rect.x + rect.w / 2, rect.y + rect.h / 2, rect.w * .24, rect.h * .46, 0, 0, Math.PI * 2); context.stroke(); break;
    case 'start_position':
      context.fillStyle = '#58f0ad'; context.fillRect(rect.x + 3, rect.y + 3, rect.w - 6, rect.h - 6); context.fillStyle = '#0b2a25'; context.font = `bold ${Math.max(12, rect.h * .45)}px system-ui`; context.textAlign = 'center'; context.fillText('▶', rect.x + rect.w / 2, rect.y + rect.h * .68); break;
    case 'checkpoint':
      context.fillStyle = '#ffe66a'; context.fillRect(rect.x + rect.w * .25, rect.y - rect.h, 5, rect.h * 2); context.font = `bold ${Math.max(14, rect.h * .65)}px system-ui`; context.fillText('◇', rect.x + rect.w * .55, rect.y + rect.h * .45); break;
    case 'finish':
      context.fillStyle = '#63e6ff'; context.fillRect(rect.x + rect.w * .35, rect.y - rect.h * 1.5, 5, rect.h * 2.5); context.fillStyle = '#eef2ff'; context.fillRect(rect.x + rect.w * .35 + 5, rect.y - rect.h * 1.42, rect.w * .78, rect.h * .55); break;
    default: break;
  }
  if (selected) {
    context.strokeStyle = '#ffffff'; context.lineWidth = 3; context.setLineDash([7, 5]); context.strokeRect(rect.x - 3, rect.y - 3, rect.w + 6, rect.h + 6); context.setLineDash([]);
  }
  context.restore();
}

function drawEditor() {
  editorDirty = false;
  clearCanvas(ectx, dom.editorCanvas, editorMetrics);
  const theme = currentTheme();
  const gridPixels = editorGridPixels();
  const groundY = editorGroundY();
  drawGrid(ectx, editorMetrics, gridPixels, cameraX, theme, groundY);
  const objects = currentLevel().objects;
  objects.forEach((obj, index) => drawObject(ectx, obj, objectRect(obj), index === selectedObjectIndex));
  const cursorRect = objectRect({ x: editorCursor.x, y: editorCursor.y, w: 1, h: 1 });
  ectx.save();
  ectx.strokeStyle = '#ffffff'; ectx.lineWidth = 2; ectx.setLineDash([4, 4]); ectx.strokeRect(cursorRect.x + 2, cursorRect.y + 2, cursorRect.w - 4, cursorRect.h - 4); ectx.restore();
  dom.cursorText.textContent = `x: ${editorCursor.x} · y: ${editorCursor.y}`;
  dom.editorLevelSubtitle.textContent = `Niveau ${String(currentLevel().order).padStart(2, '0')} · ${objects.length} objets`;
}

function screenToGrid(clientX, clientY) {
  const rect = dom.editorCanvas.getBoundingClientRect();
  const px = clientX - rect.left;
  const py = clientY - rect.top;
  const gridPixels = editorGridPixels();
  return {
    x: Math.max(0, Math.floor(cameraX + px / gridPixels)),
    y: Math.max(0, Math.floor((editorGroundY() - py) / gridPixels)),
  };
}
function objectAtCell(position) {
  const objects = currentLevel().objects;
  for (let index = objects.length - 1; index >= 0; index -= 1) {
    const obj = objects[index];
    const width = Number(obj.w || 1); const height = Number(obj.h || 1);
    if (position.x >= obj.x && position.x < obj.x + width && position.y >= obj.y && position.y < obj.y + height) return index;
  }
  return -1;
}
function removeAt(position) {
  const level = currentLevel();
  const before = level.objects.length;
  level.objects = level.objects.filter((obj) => !(position.x >= obj.x && position.x < obj.x + Number(obj.w || 1) && position.y >= obj.y && position.y < obj.y + Number(obj.h || 1)));
  if (level.objects.length !== before) selectedObjectIndex = -1;
}
function placeAt(position, shouldReplace = false) {
  const tool = currentTool();
  const level = currentLevel();
  if (tool.id === 'erase') { removeAt(position); return; }
  if (tool.id === 'select') { selectedObjectIndex = objectAtCell(position); return; }
  if (tool.id === 'pan' || tool.id === 'grid' || tool.utility) return;
  if (tool.type === 'finish' || tool.type === 'start_position') level.objects = level.objects.filter((obj) => obj.type !== tool.type);
  if (shouldReplace) removeAt(position);
  const duplicate = level.objects.some((obj) => obj.type === tool.type && obj.x === position.x && obj.y === position.y && Number(obj.w || 1) === Number(tool.preset?.w || 1));
  if (duplicate) return;
  const object = { type: tool.type, x: position.x, y: tool.type === 'finish' ? 0 : position.y, ...(tool.preset || {}) };
  level.objects.push(object);
  selectedObjectIndex = level.objects.length - 1;
}
function afterEditorMutation(message = 'Niveau modifié') {
  validateCurrentLevel(); syncEditorHeader(); requestEditorDraw(); dom.statusText.textContent = message;
}

function pointerAverage() {
  const values = [...pointerState.pointers.values()];
  if (!values.length) return 0;
  return values.reduce((sum, point) => sum + point.x, 0) / values.length;
}
function handleEditorPointerDown(event) {
  event.preventDefault();
  dom.canvasWrap.classList.add('interacted');
  dom.editorCanvas.setPointerCapture?.(event.pointerId);
  pointerState.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
  const position = screenToGrid(event.clientX, event.clientY);
  editorCursor = position;
  pointerState.lastCell = `${position.x}:${position.y}`;
  pointerState.moved = false;
  if (pointerState.pointers.size >= 2 || currentTool().id === 'pan' || event.button === 1 || event.button === 2) {
    pointerState.mode = 'pan'; pointerState.startX = pointerAverage(); pointerState.startCamera = cameraX; return;
  }
  if (currentTool().id === 'select') {
    const index = objectAtCell(position);
    selectedObjectIndex = index;
    if (index >= 0) { snapshot(); pointerState.mode = 'move'; }
    else pointerState.mode = 'select';
    requestEditorDraw(); return;
  }
  snapshot();
  pointerState.mode = currentTool().id === 'erase' ? 'erase' : 'paint';
  placeAt(position, pointerState.mode === 'paint');
  afterEditorMutation();
}
function handleEditorPointerMove(event) {
  if (pointerState.pointers.has(event.pointerId)) pointerState.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
  const position = screenToGrid(event.clientX, event.clientY);
  editorCursor = position;
  dom.cursorText.textContent = `x: ${position.x} · y: ${position.y}`;
  if (!pointerState.mode) { requestEditorDraw(); return; }
  if (pointerState.pointers.size >= 2 && pointerState.mode !== 'pan') {
    pointerState.mode = 'pan'; pointerState.startX = pointerAverage(); pointerState.startCamera = cameraX;
  }
  if (pointerState.mode === 'pan') {
    const delta = (pointerState.startX - pointerAverage()) / editorGridPixels();
    setCamera(pointerState.startCamera + delta); pointerState.moved = true; return;
  }
  const key = `${position.x}:${position.y}`;
  if (pointerState.mode === 'move' && selectedObjectIndex >= 0) {
    const obj = currentLevel().objects[selectedObjectIndex];
    obj.x = position.x; obj.y = obj.type === 'finish' ? 0 : position.y;
    pointerState.moved = true; afterEditorMutation('Objet déplacé'); return;
  }
  if (key !== pointerState.lastCell && (pointerState.mode === 'paint' || pointerState.mode === 'erase')) {
    pointerState.lastCell = key; placeAt(position, pointerState.mode === 'paint'); pointerState.moved = true; afterEditorMutation();
  }
}
function handleEditorPointerUp(event) {
  pointerState.pointers.delete(event.pointerId);
  if (!pointerState.pointers.size) pointerState.mode = null;
  else if (pointerState.mode === 'pan') { pointerState.startX = pointerAverage(); pointerState.startCamera = cameraX; }
}

function validateCurrentLevel() {
  if (!pack) return false;
  const level = currentLevel();
  const errors = [];
  if (!String(level.name || '').trim()) errors.push('Le nom est vide.');
  if (!Number.isFinite(Number(level.length)) || Number(level.length) < 40) errors.push('La longueur doit être au moins 40.');
  if (level.objects.filter((obj) => obj.type === 'finish').length !== 1) errors.push('Le niveau doit contenir exactement une arrivée.');
  if (level.objects.some((obj) => Number(obj.x) < 0 || Number(obj.y) < 0)) errors.push('Un objet a une position négative.');
  if (level.objects.some((obj) => Number(obj.x) > Number(level.length) + 2)) errors.push('Un objet dépasse la longueur du niveau.');
  dom.validation.classList.toggle('error', errors.length > 0);
  dom.validation.textContent = errors.length ? errors.join('\n') : `Niveau valide · ${level.objects.length} objets · GamePad prêt`;
  return errors.length === 0;
}
function saveLocal() {
  localStorage.setItem('gdu-level-pack', JSON.stringify(pack));
  dom.statusText.textContent = 'Pack sauvegardé dans le navigateur';
}
function exportPack() {
  if (!validateCurrentLevel()) return;
  const blob = new Blob([JSON.stringify(pack, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = 'gdu-level-pack.json'; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

function allBundledTracks() {
  const tracks = []; const seen = new Set();
  for (const level of pack?.levels || []) {
    if (typeof level.music === 'string' && level.music && !seen.has(level.music)) {
      seen.add(level.music); tracks.push({ file: level.music, label: `${String(level.order).padStart(2, '0')} · ${level.name}` });
    }
  }
  return tracks;
}
function refreshMusicSelect() {
  const selected = currentLevel()?.music || '';
  dom.musicSelect.innerHTML = '';
  for (const track of allBundledTracks()) {
    const option = document.createElement('option'); option.value = track.file; option.textContent = `${track.label} — ${track.file}`; dom.musicSelect.append(option);
  }
  if (selected && ![...dom.musicSelect.options].some((option) => option.value === selected)) {
    const option = document.createElement('option'); option.value = selected; option.textContent = `Personnalisée — ${selected}`; dom.musicSelect.append(option);
  }
  dom.musicSelect.value = selected;
}
function resolveMusicUrl(level = currentLevel()) {
  if (!level) return '';
  const imported = importedMusicUrls.get(level.id);
  if (imported) return imported;
  if (!level.music || level.music === 'original-required') return '';
  return `../assets/music/${encodeURIComponent(level.music)}`;
}
function setMusicStatus(message, error = false) { dom.musicStatus.textContent = message; dom.musicStatus.style.color = error ? '#ff91aa' : '#a8b0d6'; }
function loadCurrentMusic(autoplay = false, restart = false) {
  const level = currentLevel(); const url = resolveMusicUrl(level);
  refreshMusicSelect(); dom.testMusicLabel.textContent = `Musique : ${level?.music || 'aucune'}`;
  if (!url) { stopMusic(); dom.musicPlayer.removeAttribute('src'); currentMusicUrl = ''; setMusicStatus('Aucune musique assignée.', true); return; }
  if (currentMusicUrl !== url) { dom.musicPlayer.src = url; currentMusicUrl = url; dom.musicPlayer.load(); }
  if (restart) { try { dom.musicPlayer.currentTime = 0; } catch { /* metadata not ready */ } }
  setMusicStatus(`${level.name} · ${level.music}`);
  if (autoplay) dom.musicPlayer.play().catch(() => setMusicStatus('Touche LIRE pour autoriser le son.', true));
}
function toggleMusic() {
  if (!dom.musicPlayer.src) loadCurrentMusic(false, false);
  if (!dom.musicPlayer.src) return;
  if (dom.musicPlayer.paused) dom.musicPlayer.play().catch(() => setMusicStatus('Lecture audio bloquée.', true)); else dom.musicPlayer.pause();
}
function stopMusic() {
  dom.musicPlayer.pause(); try { dom.musicPlayer.currentTime = 0; } catch { /* ignore */ }
}

function buildSpatialIndex(level) {
  const index = new Map();
  level.objects.forEach((obj, objectIndex) => {
    const start = Math.floor(Number(obj.x) - 1);
    const end = Math.ceil(Number(obj.x) + Number(obj.w || 1) + 1);
    for (let cell = start; cell <= end; cell += 1) {
      if (!index.has(cell)) index.set(cell, []);
      index.get(cell).push({ obj, objectIndex });
    }
  });
  return index;
}
function testObjectsNear(x, radius = 2) {
  if (!testState) return [];
  const results = []; const seen = new Set();
  for (let cell = Math.floor(x - radius); cell <= Math.ceil(x + radius); cell += 1) {
    for (const entry of testState.spatial.get(cell) || []) {
      if (!seen.has(entry.objectIndex)) { seen.add(entry.objectIndex); results.push(entry.obj); }
    }
  }
  return results;
}
function startPositionFor(level) {
  const marker = level.objects.find((obj) => obj.type === 'start_position');
  return marker ? { x: Number(marker.x), y: Number(marker.y) } : { x: 1, y: 0 };
}
function newTestState(level, practiceMode) {
  const start = startPositionFor(level);
  return {
    level, spatial: buildSpatialIndex(level), x: start.x, y: start.y, previousY: start.y, vy: 0, gravity: 1,
    grounded: true, coyote: .08, jumpBuffer: 0, speedScale: 1, rotation: 0, dead: false, complete: false,
    accumulator: 0, lastTime: performance.now(), attempts: 1, practice: practiceMode, checkpoint: { ...start },
    consumedOrbs: new Set(), consumedPortals: new Set(), lastCheckpointId: '', resultShown: false, paused: false,
  };
}
function startTest(practiceMode = false) {
  closePauseMenu(); closeTutorial();
  if (!validateCurrentLevel()) { showView('editor'); openSettings(); return; }
  const level = clone(currentLevel());
  testState = newTestState(level, practiceMode);
  dom.testTitle.textContent = `${String(level.order).padStart(2, '0')} · ${level.name}`;
  dom.testOverlay.classList.add('open'); dom.testOverlay.setAttribute('aria-hidden', 'false');
  dom.practiceToggle.textContent = `ENTRAÎNEMENT : ${practiceMode ? 'ON' : 'OFF'}`;
  dom.practiceToggle.classList.toggle('active', practiceMode);
  dom.testAttempt.textContent = 'ESSAI 1';
  resizeTestCanvas();
  loadCurrentMusic(true, true);
  cancelAnimationFrame(testAnimationId);
  testAnimationId = requestAnimationFrame(testFrame);
}
function closeTest() {
  closePauseMenu(); closeTutorial();
  dom.testOverlay.classList.remove('open'); dom.testOverlay.setAttribute('aria-hidden', 'true');
  cancelAnimationFrame(testAnimationId); stopMusic(); testState = null;
  renderLibrary();
}
function resetTest(fromCheckpoint = true) {
  if (!testState) return;
  const state = testState;
  const start = fromCheckpoint && state.practice ? state.checkpoint : startPositionFor(state.level);
  state.x = start.x; state.y = start.y; state.previousY = start.y; state.vy = 0; state.gravity = 1; state.grounded = true;
  state.coyote = .08; state.jumpBuffer = 0; state.speedScale = 1; state.rotation = 0; state.dead = false; state.complete = false;
  state.accumulator = 0; state.lastTime = performance.now(); state.attempts += 1; state.consumedOrbs.clear(); state.consumedPortals.clear(); state.resultShown = false;
  dom.testAttempt.textContent = `ESSAI ${state.attempts}`;
  loadCurrentMusic(true, true);
}
function queueJump() {
  if (!testState) return;
  if (testState.dead || testState.complete) { resetTest(true); return; }
  testState.jumpBuffer = .12;
}
function overlapsPlayer(obj, x = testState.x, y = testState.y) {
  const width = Number(obj.w || 1); const height = Number(obj.h || 1);
  return x + PLAYER_SIZE > Number(obj.x) + .08 && x < Number(obj.x) + width - .08 && y + PLAYER_SIZE > Number(obj.y) + .05 && y < Number(obj.y) + height - .05;
}
function resolveBlocks(state, previousY) {
  const blocks = testObjectsNear(state.x, 2).filter((obj) => obj.type === 'block');
  state.grounded = false;
  for (const block of blocks) {
    const left = Number(block.x); const right = left + Number(block.w || 1); const bottom = Number(block.y); const top = bottom + Number(block.h || 1);
    const horizontal = state.x + PLAYER_SIZE > left + .04 && state.x < right - .04;
    if (!horizontal) continue;
    if (state.gravity > 0 && state.vy <= 0 && previousY >= top - .04 && state.y <= top + .03) {
      state.y = top; state.vy = 0; state.grounded = true; continue;
    }
    if (state.gravity < 0 && state.vy >= 0 && previousY + PLAYER_SIZE <= bottom + .04 && state.y + PLAYER_SIZE >= bottom - .03) {
      state.y = bottom - PLAYER_SIZE; state.vy = 0; state.grounded = true; continue;
    }
    if (overlapsPlayer(block)) { state.dead = true; return; }
  }
}
function stepTest(dt) {
  const state = testState;
  if (!state || state.dead || state.complete || state.paused) return;
  state.jumpBuffer = Math.max(0, state.jumpBuffer - dt);
  state.coyote = state.grounded ? .08 : Math.max(0, state.coyote - dt);
  const nearbyBefore = testObjectsNear(state.x, 2);
  const orb = nearbyBefore.find((obj) => obj.type === 'orb' && !state.consumedOrbs.has(`${obj.x}:${obj.y}`) && Math.abs(Number(obj.x) - state.x) < .9 && Math.abs(Number(obj.y) - state.y) < 1.2);
  if (state.jumpBuffer > 0 && orb) {
    state.vy = 13.2 * state.gravity; state.jumpBuffer = 0; state.grounded = false; state.consumedOrbs.add(`${orb.x}:${orb.y}`);
  } else if (state.jumpBuffer > 0 && (state.grounded || state.coyote > 0)) {
    state.vy = 11.7 * state.gravity; state.jumpBuffer = 0; state.grounded = false; state.coyote = 0;
  }
  state.previousY = state.y;
  state.vy -= 31 * state.gravity * dt;
  state.y += state.vy * dt;
  state.x += 8.2 * Number(state.level.speed || 1) * state.speedScale * dt;
  if (state.gravity > 0 && state.y <= 0) { state.y = 0; state.vy = 0; state.grounded = true; }
  if (state.gravity < 0 && state.y + PLAYER_SIZE >= 9) { state.y = 9 - PLAYER_SIZE; state.vy = 0; state.grounded = true; }
  resolveBlocks(state, state.previousY);
  if (state.dead) return;
  const nearby = testObjectsNear(state.x, 2);
  for (const obj of nearby) {
    const key = `${obj.type}:${obj.x}:${obj.y}`;
    if (obj.type === 'jump_pad' && Math.abs(Number(obj.x) - state.x) < .72 && Math.abs(state.y - Number(obj.y)) < .5) {
      state.vy = 15.2 * state.gravity; state.grounded = false;
    }
    if ((obj.type === 'gravity_portal' || obj.type === 'speed_portal') && Math.abs(Number(obj.x) - state.x) < .58 && !state.consumedPortals.has(key)) {
      if (obj.type === 'gravity_portal') { state.gravity *= -1; state.vy = 4 * state.gravity; }
      else state.speedScale = clamp(Number(obj.speed || 1.25), .55, 2.2);
      state.consumedPortals.add(key);
    }
    if (obj.type === 'checkpoint' && state.practice && Math.abs(Number(obj.x) - state.x) < .55) {
      const checkpointKey = `${obj.x}:${obj.y}`;
      if (checkpointKey !== state.lastCheckpointId) { state.checkpoint = { x: Number(obj.x), y: Number(obj.y) }; state.lastCheckpointId = checkpointKey; }
    }
    if ((obj.type === 'spike' || obj.type === 'saw') && overlapsPlayer(obj)) { state.dead = true; break; }
    if (obj.type === 'finish' && state.x >= Number(obj.x)) { state.complete = true; break; }
  }
  if (state.y < -2 || state.y > 11) state.dead = true;
  if (state.x >= Number(state.level.length)) state.complete = true;
  state.rotation += 480 * dt * state.gravity;
  if (state.grounded) state.rotation += (Math.round(state.rotation / 90) * 90 - state.rotation) * Math.min(1, dt * 16);
  if (state.dead || state.complete) {
    dom.musicPlayer.pause();
    const percent = clamp(Math.floor((state.x / Number(state.level.length)) * 100), 0, 100);
    updateStoredProgress(state.level.id, state.complete ? 100 : percent);
  }
}
function testFrame(now) {
  if (!testState || !dom.testOverlay.classList.contains('open')) return;
  const state = testState;
  if (state.paused) { state.lastTime = now; drawTest(); testAnimationId = requestAnimationFrame(testFrame); return; }
  const frame = Math.min(MAX_FRAME, (now - state.lastTime) / 1000);
  state.lastTime = now;
  state.accumulator += frame;
  let steps = 0;
  while (state.accumulator >= FIXED_STEP && steps < 8) { stepTest(FIXED_STEP); state.accumulator -= FIXED_STEP; steps += 1; }
  drawTest();
  testAnimationId = requestAnimationFrame(testFrame);
}
function testObjectRect(obj, camera, gridPixels, groundY) {
  return { x: (Number(obj.x) - camera) * gridPixels, y: groundY - (Number(obj.y) + Number(obj.h || 1)) * gridPixels, w: Number(obj.w || 1) * gridPixels, h: Number(obj.h || 1) * gridPixels };
}
function drawTest() {
  const state = testState; if (!state) return;
  clearCanvas(tctx, dom.testCanvas, testMetrics);
  const theme = THEMES[state.level.theme] || THEMES.neon;
  const gridPixels = clamp(testMetrics.height / 11.5, 28, 42);
  const groundY = testMetrics.height - 55;
  const camera = Math.max(0, state.x - 5.2);
  tctx.fillStyle = theme.sky; tctx.fillRect(0, 0, testMetrics.width, testMetrics.height);
  tctx.globalAlpha = .22; tctx.fillStyle = theme.color;
  for (let i = 0; i < 12; i += 1) { const x = ((i * 137 - camera * 9) % (testMetrics.width + 120)) - 60; const y = 45 + (i * 73) % Math.max(80, groundY - 80); tctx.fillRect(x, y, 34, 34); }
  tctx.globalAlpha = 1;
  tctx.fillStyle = theme.ground; tctx.fillRect(0, groundY, testMetrics.width, testMetrics.height - groundY);
  tctx.fillStyle = theme.color; tctx.fillRect(0, groundY, testMetrics.width, 4);
  for (const obj of state.level.objects) {
    const rect = testObjectRect(obj, camera, gridPixels, groundY);
    if (rect.x + rect.w < -80 || rect.x > testMetrics.width + 80) continue;
    drawObject(tctx, obj, rect, false, 1, testMetrics.width);
  }
  const playerX = (state.x - camera) * gridPixels;
  const playerY = groundY - (state.y + PLAYER_SIZE) * gridPixels;
  const size = PLAYER_SIZE * gridPixels;
  tctx.save(); tctx.translate(playerX + size / 2, playerY + size / 2); tctx.rotate((state.rotation * Math.PI) / 180);
  tctx.fillStyle = state.dead ? '#ff5d86' : '#f7fbff'; tctx.fillRect(-size / 2, -size / 2, size, size);
  tctx.fillStyle = '#13203c'; tctx.fillRect(-size * .27, -size * .2, size * .16, size * .16); tctx.fillRect(size * .11, -size * .2, size * .16, size * .16); tctx.restore();
  const percentage = clamp((state.x / Number(state.level.length)) * 100, 0, 100);
  tctx.fillStyle = '#ffffff20'; tctx.fillRect(18, 17, testMetrics.width - 36, 8); tctx.fillStyle = theme.color; tctx.fillRect(18, 17, (testMetrics.width - 36) * percentage / 100, 8);
  tctx.fillStyle = '#fff'; tctx.font = 'bold 13px system-ui'; tctx.fillText(`${Math.floor(percentage)}%`, 18, 43);
  if (state.practice && state.lastCheckpointId) { tctx.fillStyle = '#ffe66a'; tctx.fillText('CHECKPOINT', 78, 43); }
  if (state.dead || state.complete) {
    tctx.fillStyle = '#050817cc'; tctx.fillRect(0, 0, testMetrics.width, testMetrics.height);
    tctx.fillStyle = state.complete ? '#58f0ad' : '#ff7896'; tctx.textAlign = 'center'; tctx.font = `900 ${clamp(testMetrics.width / 22, 28, 48)}px system-ui`;
    tctx.fillText(state.complete ? 'NIVEAU TERMINÉ' : 'ÉCHEC', testMetrics.width / 2, testMetrics.height * .43);
    tctx.fillStyle = '#fff'; tctx.font = '700 15px system-ui';
    tctx.fillText(state.complete ? 'A pour rejouer · START pour le menu' : 'A pour recommencer', testMetrics.width / 2, testMetrics.height * .54); tctx.textAlign = 'left';
  }
}

function importPackFile(file) {
  if (!file) return;
  file.text().then((text) => {
    const imported = JSON.parse(text);
    if (!Array.isArray(imported.levels) || !imported.levels.length) throw new Error('Format invalide');
    pack = imported; normalizePack(); saveLocal(); loadLevel(0, true); showView('library');
  }).catch((error) => { showView('editor'); openSettings(); dom.validation.classList.add('error'); dom.validation.textContent = `Import impossible : ${error.message}`; });
}

function isTextFieldActive() {
  return ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement?.tagName);
}
function placeAtCursor() {
  if (currentView !== 'editor') return;
  snapshot(); placeAt(editorCursor, true); afterEditorMutation('Objet placé au curseur GamePad');
}
function eraseAtCursor() {
  if (currentView !== 'editor') return;
  snapshot(); removeAt(editorCursor); afterEditorMutation('Objet effacé');
}
function moveCursor(dx, dy) {
  editorCursor.x = clamp(editorCursor.x + dx, 0, Math.ceil(currentLevel().length));
  editorCursor.y = clamp(editorCursor.y + dy, 0, 12);
  const visibleStart = cameraX + 1; const visibleEnd = cameraX + editorMetrics.width / editorGridPixels() - 2;
  if (editorCursor.x < visibleStart) setCamera(editorCursor.x - 1);
  if (editorCursor.x > visibleEnd) setCamera(editorCursor.x - editorMetrics.width / editorGridPixels() + 2);
  requestEditorDraw();
}

function buttonPressed(gamepad, index) {
  const pressed = Boolean(gamepad?.buttons?.[index]?.pressed);
  const previous = Boolean(gamepadPreviousButtons[index]);
  return pressed && !previous;
}
function pollGamepad(now) {
  const gamepads = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
  const gamepad = gamepads[0];
  dom.gamepadStatus.classList.toggle('connected', Boolean(gamepad));
  dom.gamepadStatus.textContent = gamepad ? 'GAMEPAD OK' : 'GAMEPAD —';
  if (!gamepad) { gamepadPreviousButtons = []; return; }

  const a = buttonPressed(gamepad, 0);
  const b = buttonPressed(gamepad, 1);
  const l = buttonPressed(gamepad, 4);
  const r = buttonPressed(gamepad, 5);
  const select = buttonPressed(gamepad, 8);
  const start = buttonPressed(gamepad, 9);
  const dpadLeft = buttonPressed(gamepad, 14);
  const dpadRight = buttonPressed(gamepad, 15);
  const axisX = Math.abs(gamepad.axes?.[0] || 0) > .55 ? Math.sign(gamepad.axes[0]) : 0;

  if (dom.tutorialOverlay.classList.contains('open')) {
    if (select || b || start) closeTutorial();
    gamepadPreviousButtons = gamepad.buttons.map((button) => button.pressed);
    return;
  }
  if (dom.pauseOverlay.classList.contains('open')) {
    if (start || a || b) closePauseMenu();
    if (select) openTutorial();
    gamepadPreviousButtons = gamepad.buttons.map((button) => button.pressed);
    return;
  }

  if (dom.testOverlay.classList.contains('open')) {
    if (a) queueJump();
    if (start) togglePauseMenu();
    if (select) openTutorial();
  } else if (currentView === 'library') {
    if (dpadLeft || (axisX < 0 && now > gamepadAxisCooldown)) { selectRelativeLevel(-1); gamepadAxisCooldown = now + 220; }
    if (dpadRight || (axisX > 0 && now > gamepadAxisCooldown)) { selectRelativeLevel(1); gamepadAxisCooldown = now + 220; }
    if (a) startTest(practiceSelected);
    if (select) openTutorial();
  } else if (currentView === 'editor') {
    // Placement and tool selection are intentionally touch/stylus only.
    if (a) startTest(false);
    if (b) undo();
    if (dpadLeft) cycleItemPage(-1);
    if (dpadRight) cycleItemPage(1);
    if (l) cycleCategory(-1);
    if (r) cycleCategory(1);
    if (start) togglePauseMenu();
    if (select) openTutorial();
  }
  gamepadPreviousButtons = gamepad.buttons.map((button) => button.pressed);
}
function uiLoop(now) {
  pollGamepad(now);
  if (editorDirty && currentView === 'editor') drawEditor();
  uiLastTime = now;
  requestAnimationFrame(uiLoop);
}

function bindEvents() {
  dom.homeBtn.addEventListener('click', () => showView('library'));
  dom.libraryTab.addEventListener('click', () => showView('library'));
  dom.editorTab.addEventListener('click', () => showView('editor'));
  dom.backToLibraryBtn.addEventListener('click', () => showView('library'));
  dom.previousLevelBtn.addEventListener('click', () => selectRelativeLevel(-1));
  dom.nextLevelBtn.addEventListener('click', () => selectRelativeLevel(1));
  dom.editorPreviousLevel.addEventListener('click', () => selectRelativeLevel(-1));
  dom.editorNextLevel.addEventListener('click', () => selectRelativeLevel(1));
  dom.practiceBtn.addEventListener('click', () => { practiceSelected = !practiceSelected; renderLibrary(); });
  dom.playLevelBtn.addEventListener('click', () => startTest(practiceSelected));
  dom.editLevelBtn.addEventListener('click', () => showView('editor'));
  dom.levelSettingsBtn.addEventListener('click', openSettings);
  dom.closeSettingsBtn.addEventListener('click', closeSettings);
  dom.sheetBackdrop.addEventListener('click', closeSettings);
  dom.undoBtn.addEventListener('click', undo); dom.redoBtn.addEventListener('click', redo);
  dom.zoomOutBtn.addEventListener('click', () => zoomEditor(.85)); dom.zoomInBtn.addEventListener('click', () => zoomEditor(1.15));
  dom.testBtn.addEventListener('click', () => startTest(false));
  dom.resumePauseBtn.addEventListener('click', closePauseMenu);
  dom.savePauseBtn.addEventListener('click', () => { saveLocal(); closePauseMenu(); });
  dom.settingsPauseBtn.addEventListener('click', () => { closePauseMenu(); if (dom.testOverlay.classList.contains('open')) closeTest(); showView('editor'); openSettings(); });
  dom.leaveEditorPauseBtn.addEventListener('click', () => { closePauseMenu(); if (dom.testOverlay.classList.contains('open')) closeTest(); showView('library'); });
  dom.closeTutorialBtn.addEventListener('click', closeTutorial);
  dom.cameraRange.addEventListener('input', () => setCamera(maxCameraX() * Number(dom.cameraRange.value) / 1000));
  $$('#categoryTabs [data-category]').forEach((button) => button.addEventListener('click', () => setCategory(button.dataset.category)));
  dom.trayPrevious.addEventListener('click', () => cycleItemPage(-1));
  dom.trayNext.addEventListener('click', () => cycleItemPage(1));
  dom.editorCanvas.addEventListener('pointerdown', handleEditorPointerDown);
  dom.editorCanvas.addEventListener('pointermove', handleEditorPointerMove);
  dom.editorCanvas.addEventListener('pointerup', handleEditorPointerUp);
  dom.editorCanvas.addEventListener('pointercancel', handleEditorPointerUp);
  dom.editorCanvas.addEventListener('contextmenu', (event) => event.preventDefault());
  dom.editorCanvas.addEventListener('wheel', (event) => { event.preventDefault(); if (event.ctrlKey) zoomEditor(event.deltaY > 0 ? .9 : 1.1); else setCamera(cameraX + event.deltaY / editorGridPixels() + event.deltaX / editorGridPixels()); }, { passive: false });
  dom.levelSelect.addEventListener('change', () => loadLevel(Number(dom.levelSelect.value), true));
  dom.levelName.addEventListener('change', () => { snapshot(); currentLevel().name = dom.levelName.value.trim() || 'Sans titre'; refreshLevelSelect(); syncEditorHeader(); renderLibrary(); validateCurrentLevel(); });
  dom.levelLength.addEventListener('change', () => { snapshot(); currentLevel().length = Math.max(40, Number(dom.levelLength.value)); updateCameraRange(); requestEditorDraw(); validateCurrentLevel(); });
  dom.levelSpeed.addEventListener('change', () => { snapshot(); currentLevel().speed = clamp(Number(dom.levelSpeed.value), .5, 3); validateCurrentLevel(); });
  dom.saveBtn.addEventListener('click', saveLocal); dom.globalSaveBtn.addEventListener('click', saveLocal);
  dom.exportBtn.addEventListener('click', exportPack); dom.globalExportBtn.addEventListener('click', exportPack);
  dom.clearBtn.addEventListener('click', () => { snapshot(); currentLevel().objects = currentLevel().objects.filter((obj) => obj.type === 'finish'); selectedObjectIndex = -1; afterEditorMutation('Niveau vidé'); });
  dom.importInput.addEventListener('change', (event) => importPackFile(event.target.files?.[0]));
  dom.musicPlayBtn.addEventListener('click', toggleMusic); dom.musicStopBtn.addEventListener('click', stopMusic); dom.testMusicToggle.addEventListener('click', toggleMusic);
  dom.musicVolume.value = localStorage.getItem('gdu-music-volume') || '0.7'; dom.musicPlayer.volume = Number(dom.musicVolume.value);
  dom.musicVolume.addEventListener('input', () => { dom.musicPlayer.volume = Number(dom.musicVolume.value); localStorage.setItem('gdu-music-volume', dom.musicVolume.value); });
  dom.musicSelect.addEventListener('change', () => { snapshot(); currentLevel().music = dom.musicSelect.value; importedMusicUrls.delete(currentLevel().id); loadCurrentMusic(true, true); validateCurrentLevel(); });
  dom.musicImportInput.addEventListener('change', (event) => {
    const file = event.target.files?.[0]; if (!file) return;
    if (!file.type.startsWith('audio/')) { setMusicStatus('Le fichier choisi n’est pas audio.', true); return; }
    const previous = importedMusicUrls.get(currentLevel().id); if (previous) URL.revokeObjectURL(previous);
    snapshot(); const url = URL.createObjectURL(file); importedMusicUrls.set(currentLevel().id, url); currentLevel().music = file.name; refreshMusicSelect(); loadCurrentMusic(true, true);
    setMusicStatus(`Musique temporaire : ${file.name}. Copie-la dans assets/music pour l’export Wii U.`);
  });
  dom.musicPlayer.addEventListener('play', () => { dom.musicPlayBtn.textContent = '⏸ PAUSE'; dom.testMusicToggle.textContent = 'REPRENDRE'; });
  dom.musicPlayer.addEventListener('pause', () => { dom.musicPlayBtn.textContent = '▶ LIRE'; dom.testMusicToggle.textContent = 'REPRENDRE MUSIQUE'; });
  dom.musicPlayer.addEventListener('error', () => setMusicStatus(`Fichier introuvable : ${currentLevel()?.music || 'aucun'}`, true));
  dom.closeTestBtn.addEventListener('click', closeTest); dom.restartTestBtn.addEventListener('click', () => resetTest(true));
  dom.testCanvas.addEventListener('pointerdown', queueJump);
  dom.practiceToggle.addEventListener('click', () => { if (!testState) return; testState.practice = !testState.practice; dom.practiceToggle.textContent = `ENTRAÎNEMENT : ${testState.practice ? 'ON' : 'OFF'}`; dom.practiceToggle.classList.toggle('active', testState.practice); });
  window.addEventListener('keydown', (event) => {
    if (isTextFieldActive()) return;
    if (dom.testOverlay.classList.contains('open')) {
      if (['Space', 'ArrowUp', 'KeyA'].includes(event.code)) { event.preventDefault(); queueJump(); }
      if (event.code === 'Enter') togglePauseMenu();
      if (event.code === 'Tab') { event.preventDefault(); openTutorial(); }
      if (event.code === 'Escape') closeTest();
      return;
    }
    if (currentView === 'library') {
      if (event.code === 'ArrowLeft') selectRelativeLevel(-1);
      if (event.code === 'ArrowRight') selectRelativeLevel(1);
      if (event.code === 'Enter' || event.code === 'Space') startTest(practiceSelected);
      if (event.code === 'KeyE') showView('editor');
      if (event.code === 'KeyP') { practiceSelected = !practiceSelected; renderLibrary(); }
      return;
    }
    if (event.code === 'ArrowLeft') { event.preventDefault(); cycleItemPage(-1); }
    if (event.code === 'ArrowRight') { event.preventDefault(); cycleItemPage(1); }
    if (event.code === 'KeyA') { event.preventDefault(); startTest(false); }
    if (event.code === 'KeyB') { event.preventDefault(); undo(); }
    if (event.code === 'KeyL') cycleCategory(-1);
    if (event.code === 'KeyR') cycleCategory(1);
    if (event.code === 'Enter') togglePauseMenu();
    if (event.code === 'Tab') { event.preventDefault(); openTutorial(); }
    if ((event.ctrlKey || event.metaKey) && event.code === 'KeyZ') { event.preventDefault(); event.shiftKey ? redo() : undo(); }
    if ((event.ctrlKey || event.metaKey) && event.code === 'KeyY') { event.preventDefault(); redo(); }
    if (event.code === 'Equal' || event.code === 'NumpadAdd') zoomEditor(1.1); if (event.code === 'Minus' || event.code === 'NumpadSubtract') zoomEditor(.9);
  });
  if (typeof ResizeObserver !== 'undefined') {
    const observer = new ResizeObserver(() => { resizeEditorCanvas(); resizeTestCanvas(); });
    observer.observe(dom.canvasWrap); observer.observe(dom.testCanvas);
  } else {
    window.addEventListener('resize', () => { resizeEditorCanvas(); resizeTestCanvas(); });
  }
  window.addEventListener('blur', () => { pointerState.pointers.clear(); pointerState.mode = null; });
}

bindEvents();
renderObjectTray();
loadPack();
requestAnimationFrame(uiLoop);
