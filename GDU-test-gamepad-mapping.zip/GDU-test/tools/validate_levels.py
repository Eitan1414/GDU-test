#!/usr/bin/env python3
"""Validate the GDU JSON level pack without third-party dependencies."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ALLOWED_TYPES = {
    "block", "spike", "saw", "jump_pad", "orb", "gravity_portal",
    "speed_portal", "start_position", "checkpoint", "finish",
}
ALLOWED_AUDIO_SUFFIXES = {".ogg", ".mp3", ".wav"}


def validate(path: Path) -> list[str]:
    errors: list[str] = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"Cannot read {path}: {exc}"]

    levels = data.get("levels")
    if not isinstance(levels, list):
        return ["Root property 'levels' must be an array."]
    if len(levels) != 21:
        errors.append(f"Expected 21 levels, found {len(levels)}.")

    ids: set[str] = set()
    names: set[str] = set()
    previous_difficulty = 0

    for index, level in enumerate(levels, start=1):
        prefix = f"level[{index}]"
        if not isinstance(level, dict):
            errors.append(f"{prefix} must be an object.")
            continue
        level_id = level.get("id")
        name = level.get("name")
        if not isinstance(level_id, str) or not level_id:
            errors.append(f"{prefix}.id is missing.")
        elif level_id in ids:
            errors.append(f"Duplicate id: {level_id}")
        ids.add(level_id)
        if not isinstance(name, str) or not name.strip():
            errors.append(f"{prefix}.name is missing.")
        elif name in names:
            errors.append(f"Duplicate name: {name}")
        names.add(name)

        difficulty = level.get("difficulty")
        if not isinstance(difficulty, int) or not 1 <= difficulty <= 10:
            errors.append(f"{prefix}.difficulty must be an integer from 1 to 10.")
        elif difficulty < previous_difficulty:
            errors.append(f"{prefix}.difficulty decreases unexpectedly.")
        else:
            previous_difficulty = difficulty

        length = level.get("length")
        if not isinstance(length, (int, float)) or length < 40:
            errors.append(f"{prefix}.length must be at least 40.")

        music = level.get("music")
        if not isinstance(music, str) or not music.strip():
            errors.append(f"{prefix}.music is missing.")
        else:
            music_path = path.parent.parent / "music" / music
            if Path(music).suffix.lower() not in ALLOWED_AUDIO_SUFFIXES:
                errors.append(f"{prefix}.music must be .ogg, .mp3 or .wav.")
            if not music_path.is_file():
                errors.append(f"{prefix}.music file does not exist: {music_path}")

        objects = level.get("objects")
        if not isinstance(objects, list):
            errors.append(f"{prefix}.objects must be an array.")
            continue
        if sum(1 for obj in objects if isinstance(obj, dict) and obj.get("type") == "finish") != 1:
            errors.append(f"{prefix} must contain exactly one finish object.")
        for obj_index, obj in enumerate(objects):
            if not isinstance(obj, dict):
                errors.append(f"{prefix}.objects[{obj_index}] must be an object.")
                continue
            if obj.get("type") not in ALLOWED_TYPES:
                errors.append(f"{prefix}.objects[{obj_index}] has unknown type {obj.get('type')!r}.")
            if not isinstance(obj.get("x"), (int, float)) or obj["x"] < 0:
                errors.append(f"{prefix}.objects[{obj_index}].x must be non-negative.")
            if not isinstance(obj.get("y"), (int, float)) or obj["y"] < 0:
                errors.append(f"{prefix}.objects[{obj_index}].y must be non-negative.")

    return errors


def main() -> int:
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("assets/levels/pack.json")
    errors = validate(path)
    if errors:
        print("Level validation failed:")
        for error in errors:
            print(f"- {error}")
        return 1
    print(f"OK: {path} contains 21 valid levels and all music files are present.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
